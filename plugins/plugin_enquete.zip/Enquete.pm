package Koha::Plugin::Enquete;

use Modern::Perl;
use warnings;
use utf8;

use base qw(Koha::Plugins::Base);
use C4::Context;
use Koha::AuthorisedValues;
use Time::Piece;
use Data::Dumper;

our $VERSION = 1.00;

my $time = Time::Piece->new();
my $year = $time->year - 1; # valeur par défaut
my $dateKoha = 0;

sub new {
    my ( $class, $args ) = @_;

    $args->{"metadata"} = {
        name   => "Annual report",
        author => "Maryse Simard",
        description => "Generates the annual report for the year $year.",
        date_authored   => "2019-01-10",
        date_updated    => "2019-01-10",
        minimum_version => "17.05", # exactement 16.12.00.004
        maximum_version => undef,
        version         => $VERSION,
    };

    my $self = $class->SUPER::new($args);
    return $self;
}

sub tool {
    my ( $self, $args ) = @_;
    my $cgi = $self->{"cgi"};

    my $dbh = C4::Context->dbh;
    my $table_questions       = $self->get_qualified_table_name("questions");
    my $table_contraintes     = $self->get_qualified_table_name("contraintes");
    my $table_sql             = $self->get_qualified_table_name("sql");
    my $query_insert_criteria = "INSERT INTO $table_contraintes (question_id, critere, type, valeurs) VALUES (?,?,?,?)";
    my $query_insert_sql      = "INSERT INTO $table_sql (question_id, sql_text, date_generee) VALUES (?, ?, NOW())";

    # sauvegarde des données et génération du rapport
    if ( $cgi->param("save") ) {
        $dbh->do("DELETE FROM $table_contraintes");
        $dbh->do("ALTER TABLE $table_contraintes AUTO_INCREMENT = 0");

        my @questions = $cgi->multi_param("question_id");

        for ( my $i = 0 ; $i <= $#questions ; $i++ ) {
            my $id = $questions[$i];

            # publié au Québec
            my $quebec = $cgi->param("quebec$id") || 0;
            $dbh->prepare("UPDATE $table_questions SET quebec = ? WHERE id = ?")->execute($quebec, $id);

            # est active
            my $active = $cgi->param("active$id") || 0;
            $dbh->prepare("UPDATE $table_questions SET active = ? WHERE id = ?")->execute($active, $id);

            my @criterias = $cgi->multi_param("criteria$id");
            my $critere = 0;
            my $sql;
            for ( my $j = 0 ; $j <= $#criterias ; $j++ ) {
                my $criteria        = $criterias[$j];
                my @itemtypes       = $cgi->multi_param("selectItemitemtype${id}_$criteria");
                my @locations       = $cgi->multi_param("selectItemlocation${id}_$criteria");
                my @collections     = $cgi->multi_param("selectItemcollection${id}_$criteria");
                my $callnumber      = $cgi->param("callnumber${id}_$criteria");
                my $callnumber_type = $cgi->param("callnumber_type${id}_$criteria");
                next unless (scalar @itemtypes or scalar @locations or scalar @collections or length $callnumber);

                $sql .= " or" if ( length $sql );
                $sql .= " (";

                my $types_str = join ",", map { "'$_'" } @itemtypes;
                if ( length $types_str ) {
                    my $sth = $dbh->prepare($query_insert_criteria);
                    $sth->execute($id, $critere, "DOCTYPE", $types_str);
                    $sql .= "items.itype in ($types_str)";
                }

                my $locs_str = join ",", map { "'$_'" } @locations;
                if ( length $locs_str ) {
                    my $sth = $dbh->prepare($query_insert_criteria);
                    $sth->execute($id, $critere, "LOC", $locs_str);
                    $sql .= " and " if ( length $types_str );
                    $sql .= "items.location in ($locs_str)";
                }

                my $colls_str = join ",", map { "'$_'" } @collections;
                if ( length $colls_str ) {
                    my $sth = $dbh->prepare($query_insert_criteria);
                    $sth->execute($id, $critere, "CCODE", $colls_str);
                    $sql .= " and " if ( length $types_str or length $locs_str );
                    $sql .= "items.ccode in ($colls_str)";
                }

                if ( length $callnumber ) {
                    $callnumber = "%" . $callnumber if ( $callnumber_type eq "contains" );
                    $callnumber = "'$callnumber%'";

                    my $sth = $dbh->prepare($query_insert_criteria);
                    $sth->execute($id, $critere, "callnumber", $callnumber);
                    $sql .= " and " if ( length $types_str or length $locs_str or length $colls_str );
                    $sql .= "items.itemcallnumber like $callnumber";
                }

                $sql .= ")";
                $critere++;
            }

            my $sth = $dbh->prepare($query_insert_sql);
            $sth->execute($id, "WHERE$sql");
        }

        generate_report($self);

    # affichage des questions pour modification
    } else {
        # récupère les données existantes
        my $query_questions = "SELECT * FROM $table_questions";
        my $sth_questions = $dbh->prepare($query_questions);
        $sth_questions->execute();

        my @questions;
        my $criterias_exists = 1;
        while ( my $data_questions = $sth_questions->fetchrow_hashref ) {
            my $query_criterias = "SELECT * FROM $table_contraintes WHERE question_id = ?";
            my $sth_criterias = $dbh->prepare($query_criterias);
            $sth_criterias->execute($data_questions->{id});

            my @criterias;
            while ( my $data_criterias = $sth_criterias->fetchrow_hashref ) {
                my $value;
                my @values;
                if ( $data_criterias->{type} eq "callnumber" ) {
                    $value = $data_criterias->{valeurs};
                    unless ( $value =~ m/^'%/ ) {
                        $criterias[$data_criterias->{critere}]{ startswith } = 1;
                    }
                    $value = $value =~ s/'//gr =~ s/%//gr;
                   push @values, $value;
                } else {
                    $value =  $data_criterias->{valeurs} =~ s/'//gr;
                    @values = split /,/, $value;
                }

                $criterias[$data_criterias->{critere}]{ $data_criterias->{type} } = \@values;
            }

            $criterias_exists = 0 unless ( @criterias or !$data_questions->{active} );
            $data_questions->{criterias} = \@criterias;
            push @questions, $data_questions;
        }

        # get itemtypes, locations and collections
        my $itemtypes   = Koha::ItemTypes->search();
        my $locations   = Koha::AuthorisedValues->search( { category => "LOC" } );
        my $collections = Koha::AuthorisedValues->search( { category => "CCODE" } );

        my $template = get_template_enquete($self, "enquete");
        #warn Dumper(@questions);
        #warn Dumper($itemtypes);
        $template->param(
            questions        => \@questions,
            itemtypes        => $itemtypes,
            locations        => $locations,
            collections      => $collections,
            criterias_exists => $criterias_exists,
        );

        my $conf_year = $self->retrieve_data("year");
        $year = $conf_year if ($conf_year);
        $template->param( year => $year);

        print $cgi->header( -type => "text/html", -charset => "utf8" );
        print $template->output();
    }
}

# génération du rapport
sub generate_report {
    my $self = shift;
    my $cgi = $self->{"cgi"};
    my $template = get_template_enquete($self, "rapport_content");

    my $conf_year = $self->retrieve_data("year");
    $year = $conf_year if ($conf_year);
    
    my $conf_dateKoha = $self->retrieve_data("dateKoha");
    my $dateKoha = $conf_dateKoha if ($conf_dateKoha);

    my $dbh = C4::Context->dbh;
    my $table_questions = $self->get_qualified_table_name("questions");
    my $table_sql       = $self->get_qualified_table_name("sql");

    my $query_questions = "SELECT * FROM $table_sql s
        LEFT JOIN $table_questions q ON q.id = question_id
        WHERE s.id IN (SELECT MAX(id) FROM $table_sql GROUP BY question_id)";
    my $sth_questions = $dbh->prepare($query_questions);
    $sth_questions->execute();

    # réponses pour chaque question de l'enquête
    my %answers;
    while ( my $question = $sth_questions->fetchrow_hashref ) {
        my %answer;

        if ( $question->{active} ) {
            my $sql = $question->{sql_text};
            %answer = get_answers($sql, $year, $question->{quebec}, $dateKoha);
        } else {
            %answer = ( inactive => 1,
                titles_acq         => 0,
                titles_acq_quebec  => 0,
                titles_fund        => 0,
                titles_fund_quebec => 0,
                items_acq          => 0,
                items_acq_quebec   => 0,
                items_fund         => 0,
                items_fund_quebec  => 0,
                loans_adults       => 0,
                loans_childs       => 0,
            );
        }

        $answer{description} = $question->{description};
        $answers{$question->{id}} = \%answer;
    }

    # données générales
    # retraits
    my $query = "SELECT COUNT(*) FROM deleteditems WHERE YEAR(timestamp) = ?";
    my $sth = $dbh->prepare($query);
    $sth->execute($year);
    my $eliminations = $sth->fetchrow;

    # utilisateurs
    $query = "SELECT count(*) FROM borrowers
        LEFT JOIN categories ON borrowers.categorycode = categories.categorycode
        WHERE YEAR(dateexpiry) > ? AND YEAR(dateenrolled) <= ?
        AND category_type IN ";
    $sth = $dbh->prepare($query . "('A', 'S', 'P')");
    $sth->execute($year, $year);
    my $users_adults = $sth->fetchrow;

    $sth = $dbh->prepare($query . "('C')");
    $sth->execute($year, $year);
    my $users_childs = $sth->fetchrow;

    $sth = $dbh->prepare($query . "('I')");
    $sth->execute($year, $year);
    my $users_institutions = $sth->fetchrow;

    $query = "SELECT COUNT(DISTINCT borrowers.borrowernumber) FROM borrowers
        LEFT JOIN (SELECT * FROM issues UNION SELECT * FROM old_issues) issues ON borrowers.borrowernumber = issues.borrowernumber
        LEFT JOIN old_issues ON borrowers.borrowernumber = old_issues.borrowernumber
        WHERE YEAR(issues.issuedate) = ? AND YEAR(borrowers.dateenrolled) <= ? AND YEAR(dateexpiry) >= ?";
    $sth = $dbh->prepare($query);
    $sth->execute($year, $year, $year);
    my $users_active = $sth->fetchrow;

    # publications
    $query = "SELECT count(*) FROM subscription LEFT JOIN biblio_metadata USING(biblionumber)
        WHERE ( YEAR(startdate) <= ? AND YEAR(enddate) >= ? )";
    $sth = $dbh->prepare($query);
    $sth->execute($year, $year);
    my $subscriptions = $sth->fetchrow;

    $query .= "AND SUBSTR(metadata, INSTR(metadata, '<controlfield tag=\"008\">')+24+15, 3) LIKE \"\%q%\"";
    $sth = $dbh->prepare($query);
    $sth->execute($year, $year);
    my $subscriptions_quebec = $sth->fetchrow;

    # autres documents
    $query = "SELECT COUNT(itemnumber)
        FROM (SELECT * FROM biblio UNION SELECT * FROM deletedbiblio) biblio
        LEFT JOIN (SELECT * FROM items UNION SELECT * FROM deleteditems) items USING(biblionumber)
        WHERE (YEAR(biblio.datecreated) = ? OR YEAR(items.dateaccessioned) = ?)";
    $sth = $dbh->prepare($query);
    $sth->execute($year, $year);
    my $all_acq = $sth->fetchrow;
    $query = $query =~ s/=/<=/gr;
    $sth = $dbh->prepare($query);
    $sth->execute($year, $year);
    my $all_fund = $sth->fetchrow;

    # prêts autres documents
    my $query_loan = "SELECT COUNT(*) FROM statistics
        LEFT JOIN borrowers USING(borrowernumber)
        LEFT JOIN categories ON categories.categorycode = borrowers.categorycode
        AND statistics.type IN ('issue', 'renew')
        AND YEAR(statistics.datetime) = ?
        AND category_type IN ";
    my $sth_loan = $dbh->prepare($query_loan . "('A', 'S', 'P')");
    $sth_loan->execute($year);
    my $all_loans_adults = $sth_loan->fetchrow;

    $sth_loan = $dbh->prepare($query_loan . "('C')");
    $sth_loan->execute($year);
    my $all_loans_childs = $sth_loan->fetchrow;

    foreach my $answer (values %answers) {
        if ( !$answer->{invalid} ) {
            $all_acq -= $answer->{items_acq};
            $all_fund -= $answer->{items_fund};
            $all_loans_adults -= $answer->{loans_adults};
            $all_loans_childs -= $answer->{loans_childs};
        }
    }
    #warn Dumper(%answers);
    my $itemtypes   = Koha::ItemTypes->search();
    my @questions = get_questions($self, $dbh);
    warn Dumper(@questions); 
    $template->param(
        answers            => \%answers,
        eliminations       => $eliminations,
        users_adults       => $users_adults,
        users_childs       => $users_childs,
        users_institutions => $users_institutions,
        users_active       => $users_active,
        subscriptions      => $subscriptions,
        subscriptions_quebec => $subscriptions_quebec,
        other_items_acq          => $all_acq,
        other_items_fund         => $all_fund,
        other_items_loans_adults => $all_loans_adults,
        other_items_loans_childs => $all_loans_childs,
        itemtypes        => $itemtypes,
        questions        => \@questions,
    );

    my $report = $template->output();
    #warn Dumper($template);

    $template = get_template_enquete($self, "rapport");
    $template->param(
        year => $year,
        report => $report,
    );

    print $cgi->header( -type => "text/html", -charset => "utf8" );
    print $template->output();
}

# exécute les requêtes correspondant à chaque question
sub get_answers {
    my $sql = shift;
    my $year = shift;
    my $quebec = shift;
    my $dateKoha = shift;
    my $dbh = C4::Context->dbh;

    my $select_titles      = "SELECT COUNT(distinct biblionumber)";
    my $select_items       = "SELECT COUNT(itemnumber)";
    my $from               = "FROM (SELECT * FROM biblio UNION SELECT * FROM deletedbiblio) biblio
                                LEFT JOIN (SELECT * FROM items UNION SELECT * FROM deleteditems) items USING (biblionumber)
                                LEFT JOIN biblio_metadata USING(biblionumber)";
    my $where_year         = "AND YEAR(items.dateaccessioned) <= ?";
    my $where_quebec       = "AND SUBSTR(metadata, INSTR(metadata, '<controlfield tag=\"008\">')+24+15, 3) LIKE \"\%q%\"";
    
    my $query_titles_fund          = "$select_titles $from $sql $where_year";
    my $query_items_fund           = "$select_items $from $sql $where_year";
    
    my $query_titles_acq         = $query_titles_fund =~ s/<=/=/gr;
    my $query_items_acq          = $query_items_fund =~ s/<=/=/gr;
    
    my ($koha_day, $koha_month, $koha_year) = $dateKoha =~ /^(\d\d)\/(\d\d)\/(\d\d\d\d)/;
    if ($dateKoha) {
        $dateKoha = "$koha_year-$koha_month-$koha_day";
        if ($koha_year == $year) {
            $where_year = "AND YEAR(items.dateaccessioned) = ? AND DATE(items.dateaccessioned) > ?"; 
            $query_titles_acq = "$select_titles $from $sql $where_year";
            $query_items_acq = "$select_titles $from $sql $where_year";
        }
    }

    my $sth_titles_acq = $dbh->prepare($query_titles_acq);
    if ($koha_year && $koha_year == $year ) {
        $sth_titles_acq->execute($year,$dateKoha);
    } else {
        $sth_titles_acq->execute($year);
    }

    my $titles_acq = $sth_titles_acq->fetchrow;

    my $sth_items_acq = $dbh->prepare($query_items_acq);
    if ($koha_year && $koha_year == $year) {
        $sth_items_acq->execute($year,$dateKoha);
    } else {
        $sth_items_acq->execute($year);
    }  
    my $items_acq = $sth_items_acq->fetchrow;

    my $sth_titles_fund = $dbh->prepare($query_titles_fund);
    $sth_titles_fund->execute($year);
    my $titles_fund = $sth_titles_fund->fetchrow;

    my $sth_items_fund = $dbh->prepare($query_items_fund);
    $sth_items_fund->execute($year);
    my $items_fund = $sth_items_fund->fetchrow;

    my $titles_acq_quebec  = 0;
    my $items_acq_quebec   = 0;
    my $titles_fund_quebec = 0;
    my $items_fund_quebec  = 0;
    if ( $quebec ) {
        $sth_titles_acq = $dbh->prepare($query_titles_acq . $where_quebec);
        if ($koha_year && $koha_year == $year) {
                $sth_titles_acq->execute($year,$dateKoha);
        } else {
                $sth_titles_acq->execute($year);
        }   
        $titles_acq_quebec = $sth_titles_acq->fetchrow;

        $sth_items_acq = $dbh->prepare($query_items_acq . $where_quebec);
        if ($koha_year && $koha_year == $year) {
            $sth_items_acq->execute($year,$dateKoha);
        } else {
            $sth_items_acq->execute($year);
        }      
        $items_acq_quebec = $sth_items_acq->fetchrow;

        $sth_titles_fund = $dbh->prepare($query_titles_fund . $where_quebec);
        $sth_titles_fund->execute($year);
        $titles_fund_quebec = $sth_titles_fund->fetchrow;

        $sth_items_fund = $dbh->prepare($query_items_fund . $where_quebec);
        $sth_items_fund->execute($year);
        $items_fund_quebec = $sth_items_fund->fetchrow;
    }

    # prêts
    my $statsql = $sql =~ s/items\.itype/itemtype/gr;
    my $query_loan = "SELECT count(*) FROM statistics
        LEFT JOIN (SELECT * FROM items UNION SELECT * FROM deleteditems) items USING(itemnumber)
        LEFT JOIN borrowers USING(borrowernumber)
        LEFT JOIN categories ON categories.categorycode = borrowers.categorycode
        $statsql
        AND statistics.type IN ('issue', 'renew')
        AND YEAR(statistics.datetime) = ?
        AND category_type IN ";
    #warn "QUERY1212 . $query_loan";
    my $sth_loan = $dbh->prepare($query_loan . "('A', 'I', 'S', 'P')");
    $sth_loan->execute($year);
    my $loans_adults = $sth_loan->fetchrow;

    $sth_loan = $dbh->prepare($query_loan . "('C')");
    $sth_loan->execute($year);
    my $loans_childs = $sth_loan->fetchrow;

    my %answers = (
        titles_acq         => $titles_acq,
        titles_acq_quebec  => $titles_acq_quebec,
        titles_fund        => $titles_fund,
        titles_fund_quebec => $titles_fund_quebec,
        items_acq          => $items_acq,
        items_acq_quebec   => $items_acq_quebec,
        items_fund         => $items_fund,
        items_fund_quebec  => $items_fund_quebec,
        loans_adults       => $loans_adults,
        loans_childs       => $loans_childs,
    );

    return %answers;
}

sub get_questions {
    my $self = shift;
    my $dbh = shift;
    
    my $table_questions       = $self->get_qualified_table_name("questions");
    my $table_contraintes     = $self->get_qualified_table_name("contraintes");

    my $query_questions = "SELECT * FROM $table_questions";
    my $sth_questions = $dbh->prepare($query_questions);
    $sth_questions->execute();

    my @questions;
    my $criterias_exists = 1;
    while ( my $data_questions = $sth_questions->fetchrow_hashref ) { 
        my $query_criterias = "SELECT * FROM $table_contraintes WHERE question_id = ?";
        my $sth_criterias = $dbh->prepare($query_criterias);
        $sth_criterias->execute($data_questions->{id});

        my @criterias;
        while ( my $data_criterias = $sth_criterias->fetchrow_hashref ) { 
            my $value;
            my @values;
            if ( $data_criterias->{type} eq "callnumber" ) { 
                $value = $data_criterias->{valeurs};
                unless ( $value =~ m/^'%/ ) { 
                    $criterias[$data_criterias->{critere}]{ startswith } = 1;
                }
                $value = $value =~ s/'//gr =~ s/%//gr;
                push @values, $value;
            } else {
                $value =  $data_criterias->{valeurs} =~ s/'//gr;
                @values = split /,/, $value;
            }
 
            $criterias[$data_criterias->{critere}]{ $data_criterias->{type} } = \@values;
        }
 
        $criterias_exists = 0 unless ( @criterias or !$data_questions->{active} );
        $data_questions->{criterias} = \@criterias;
        push @questions, $data_questions;
    }
    return @questions;
}

sub configure {
    my ( $self, $args ) = @_;
    my $cgi = $self->{"cgi"};

    unless ( $cgi->param("save") ) {
        my $template = get_template_enquete($self, "configure");

        # Création de la base de données
        my $dbh = C4::Context->dbh;

        my $table_questions = $self->get_qualified_table_name("questions");
        $dbh->do("CREATE TABLE IF NOT EXISTS $table_questions (
            id int(11) NOT NULL auto_increment,
            description VARCHAR(50) NOT NULL,
            section VARCHAR(50) NOT NULL,
            quebec TINYINT(1) NOT NULL DEFAULT 0,
            active TINYINT(1) NOT NULL DEFAULT 1,
            PRIMARY KEY (id)
        )");

        # Ajoute les données si la table est vide
        my $sth = $dbh->prepare("SELECT COUNT(*) FROM $table_questions");
        $sth->execute();

        unless ( $sth->fetchrow ) {
            $dbh->do("INSERT INTO $table_questions (id, description, section) VALUES (1, 'Livres imprimés adulte', 'Sections : 2.1, 3.1')");
            $dbh->do("INSERT INTO $table_questions (id, description, section) VALUES (2, 'Livres imprimés jeunesse', 'Sections : 2.1, 3.1')");
            $dbh->do("INSERT INTO $table_questions (id, description, section, quebec) VALUES (3, 'Documents imprimés : Livres', 'Sections : 2.1, 3.1, 4.2', 1)");
            $dbh->do("INSERT INTO $table_questions (id, description, section) VALUES (4, 'Documents imprimés : Revues', 'Sections : 3.2, 4.2')");
            $dbh->do("INSERT INTO $table_questions (id, description, section) VALUES (5, 'Documents sonores : musique', 'Sections : 2.2, 3.3')");
            $dbh->do("INSERT INTO $table_questions (id, description, section) VALUES (6, 'Documents sonores : livres audio', 'Sections : 2.2, 3.3, 4.2')");
            $dbh->do("INSERT INTO $table_questions (id, description, section) VALUES (7, 'Documents audiovisuels : films', 'Sections : 2.2, 3.3, 4.2')");
            $dbh->do("INSERT INTO $table_questions (id, description, section) VALUES (8, 'Documents audiovisuels : jeux vidéo', 'Sections : 2.2, 3.3, 4.2')");
            $dbh->do("INSERT INTO $table_questions (id, description, section) VALUES (9, 'Documents numériques : bases de données', 'Sections : 2.3, 3.4')");
            $dbh->do("INSERT INTO $table_questions (id, description, section, quebec) VALUES (10, 'Documents numériques : revues électroniques', 'Sections : 2.3, 3.4 , 4.2' , 1)");
            $dbh->do("INSERT INTO $table_questions (id, description, section, quebec) VALUES (11, 'Documents numériques : livres numériques', 'Sections : 2.3, 3.4, 4.2', 1)");
            $dbh->do("INSERT INTO $table_questions (id, description, section, quebec) VALUES (12, 'Documents numériques : livres audio numériques', 'Sections : 2.3, 3.4, 4.2', 1)");
            $dbh->do("INSERT INTO $table_questions (id, description, section) VALUES (13, 'Documents numériques: Autres documents numériques', 'Sections : 2.3, 3.4, 4.2')");
            $dbh->do("INSERT INTO $table_questions (id, description, section) VALUES (14, 'Autres documents', 'Sections : 2.4, 3.5, 4.2') ");

            $template->param( db_created => 1 );
        }

        my $table_contraintes = $self->get_qualified_table_name("contraintes");
        $dbh->do("CREATE TABLE IF NOT EXISTS $table_contraintes (
            id int(11) NOT NULL auto_increment,
            question_id INT(11) NOT NULL,
            critere TINYINT(1),
            type VARCHAR(10),
            valeurs VARCHAR(255),
            PRIMARY KEY(id),
            CONSTRAINT ${table_contraintes}_ibfk_1 FOREIGN KEY (question_id) REFERENCES $table_questions (id) ON DELETE CASCADE ON UPDATE CASCADE
        )");

        my $table_sql = $self->get_qualified_table_name("sql");
        $dbh->do("CREATE TABLE IF NOT EXISTS $table_sql (
            id int(11) NOT NULL auto_increment,
            question_id INT(11) NOT NULL,
            sql_text LONGTEXT NOT NULL,
            date_generee DATE,
            PRIMARY KEY (id),
            CONSTRAINT ${table_sql}_ibfk_1 FOREIGN KEY (question_id) REFERENCES $table_questions (id) ON DELETE CASCADE ON UPDATE CASCADE
        )");

        my $year = $self->retrieve_data("year");
        my $dateKoha = $self->retrieve_data("dateKoha");
        $template->param( 
            year => $year,
            dateKoha => $dateKoha,
        );

        print $cgi->header( -type => "text/html", -charset => "utf8" );
        print $template->output();

    } else {
        $self->store_data(
            {
                dateKoha           => $cgi->param("dateKoha") || undef,
                year               => $cgi->param("year") || undef,
                last_configured_by => C4::Context->userenv->{"number"},
            }
        );
        $self->go_home();
    }
}

sub get_template_enquete {
    my $self = shift;
    my $name = shift;

    # Le template dépend du cookie, celui par défault est anglais
    my $preferedLanguage = $self->{"cgi"}->cookie("KohaOpacLanguage") || "";
    my $template = undef;

    eval {$template = $self->get_template( { file => $name . "_$preferedLanguage.tt" } )};
    if(!$template){
        $preferedLanguage = substr $preferedLanguage, 0, 2;
        eval {$template = $self->get_template( { file => $name . "_$preferedLanguage.tt" } )};
    }
    $template = $self->get_template( { file => "$name.tt" } ) unless $template;

    return $template;
}

#Supprimer le plugin avec toutes ses données
sub uninstall() {
    my ( $self, $args ) = @_;
    my $dbh = C4::Context->dbh;

    my $table = $self->get_qualified_table_name("contraintes");
    $dbh->do("DROP TABLE $table");

    $table = $self->get_qualified_table_name("sql");
    $dbh->do("DROP TABLE $table");

    $table = $self->get_qualified_table_name("questions");
    $dbh->do("DROP TABLE $table");

    C4::Context->dbh->do("DELETE FROM plugin_data WHERE plugin_class = Koha::Plugin::Enquete");
}

1;
